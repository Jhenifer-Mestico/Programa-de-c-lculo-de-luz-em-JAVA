package energiaeletrica;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Jhenifer
 */
public class Luz{
	
    private double consumo, fornecimento,icms,confins,pispases,icmsConfins,icmsPisPasesp,fatura;


	public double getConsumo() {
		return consumo;
	}

	public void setConsumo(double consumo) {
		this.consumo = consumo;
	}

	public double getFornecimento() {
		return fornecimento;
	}

	public void setFornecimento(double fornecimento) {
		this.fornecimento = fornecimento;
	}

	public double getIcms() {
		return icms;
	}

	public void setIcms(double icms) {
		this.icms = icms;
	}

	public double getConfins() {
		return confins;
	}

	public void setConfins(double confins) {
		this.confins = confins;
	}

	public double getPispases() {
		return pispases;
	}

	public void setPispases(double pispases) {
		this.pispases = pispases;
	}

	public double getIcmsConfins() {
		return icmsConfins;
	}

	public void setIcmsConfins(double icmsConfins) {
		this.icmsConfins = icmsConfins;
	}

	public double getIcmsPisPasesp() {
		return icmsPisPasesp;
	}

	public void setIcmsPisPasesp(double icmsPisPasesp) {
		this.icmsPisPasesp = icmsPisPasesp;
	}

	public double getFatura() {
		return fatura;
	}

	public void setFatura(double fatura) {
		this.fatura = fatura;
	}

    public Luz(double consumo) {
        this.consumo = consumo;
    }

	public void EnergiaEletrica(double consumo) {
		this.setConsumo(consumo);
	}
	public  void calculosLuz(double consumo){
		this.setFornecimento(consumo*0.28172);
		if(consumo<=200){
			this.setIcms(fornecimento*0.136363);
			this.setConfins(fornecimento*0.0614722);
			this.setPispases(fornecimento*0.013346);
			this.setIcmsConfins(fornecimento*0.0614722*0.0136363);
			this.setIcmsPisPasesp(fornecimento*0.013346*0.0136363);
		
		}
		else{
		this.setIcms(fornecimento*0.333333);
		this.setConfins(fornecimento*0.0730751);
		this.setPispases(fornecimento*0.0158651);
		this.setIcmsConfins(fornecimento*0.07307541*0.333333);
		this.setIcmsPisPasesp(fornecimento*0.0158651*0.333333);
		}

	}

   public void calculandoFatura(double fornecimento,double icms,double confins,double pispases,double icmsConfins,double icmsPisPasesp){
	   this.setFatura(fornecimento+icms+confins+pispases+icmsConfins+icmsPisPasesp);
   }


}