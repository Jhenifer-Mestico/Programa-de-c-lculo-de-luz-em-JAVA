/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package energiaeletrica;

/**
 *
 * @author Jhenifer
 */ 
import javax.swing.*;
public class EnergiaEletrica {

    public static void main(String[] args) {
        double consumo, fornecimento,icms,confins,pispases,icmsConfins,icmsPisPasesp,fatura;
         consumo = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe o seu consumo:"));
        Luz energialuz = new Luz(consumo);
        
        energialuz.calculosLuz(consumo);
        fornecimento= energialuz.getFornecimento();
        icms=energialuz.getIcms();
        confins=energialuz.getConfins();
        pispases=energialuz.getPispases();
        icmsConfins=energialuz.getIcmsConfins();
        icmsPisPasesp=energialuz.getIcmsPisPasesp();
        energialuz.calculandoFatura(fornecimento, icms, confins, pispases, icmsConfins, icmsPisPasesp);
        fatura=energialuz.getFatura();
        JOptionPane.showMessageDialog(null, "Seu fornecimento será de R$: " + fornecimento + " \n Seu ICMS será: R$" + icms+" \n Seu confins será: R$" + confins + "\n Seu pispasesp será: R$" + pispases + "\n Seu icmsConfins será: R$" + icmsConfins + "\nSeu icmsPisPasesp será: R$" + icmsPisPasesp + "\n O total da sua fatura será: R$" + fatura);

    }
    }